package com.ltimindtree.service;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ltimindtree.model.User;

public interface User_Service {
	
	public User saveUser(User user) throws JsonProcessingException;
	public void saveAllUser(List<User> getAllUser);
	public List<User> getAllUsers();
	public User getUserById(long id) throws JsonProcessingException;
	public void updateUser(User user, long id) throws JsonProcessingException;
	public void deleteUserById(long id) throws JsonProcessingException;
	public User getUserByName(String name);

}
