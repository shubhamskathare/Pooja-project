package com.ltimindtree.model;

import java.util.List;
import java.util.Objects;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="user")
public class User implements CinemaIf,Comparable<User>{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String name;
	private String password;
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	private List<PVR> pvr;
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	private List<Inox> inox;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public List<PVR> getPvr() {
		return pvr;
	}
	public void setPvr(List<PVR> pvr) {
		this.pvr = pvr;
	}
	public List<Inox> getInox() {
		return inox;
	}
	public void setInox(List<Inox> inox) {
		this.inox = inox;
	}
	@Override
	public int hashCode() {
		return Objects.hash(id, inox, name, password, pvr);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		return id == other.id && Objects.equals(inox, other.inox) && Objects.equals(name, other.name)
				&& Objects.equals(password, other.password) && Objects.equals(pvr, other.pvr);
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", password=" + password + ", pvr=" + pvr + ", inox=" + inox + "]";
	}
	public User(long id, String name, String password, List<PVR> pvr, List<Inox> inox) {
		super();
		this.id = id;
		this.name = name;
		this.password = password;
		this.pvr = pvr;
		this.inox = inox;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int compareTo(User o) {
		// TODO Auto-generated method stub
		return this.name.compareTo(o.name);
	}
	
	
	

}
