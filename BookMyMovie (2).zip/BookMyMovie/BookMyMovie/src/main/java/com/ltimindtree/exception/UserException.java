package com.ltimindtree.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value=HttpStatus.NOT_FOUND)
public class UserException extends RuntimeException{
	
	private static final long serialVersionUID= 1L;
	
	private String resName;
	private String fieldName;
	private long fieldValue;
	
	public UserException(String resName, String fieldName, long fieldValue) 
	{
		super(String.format("%s not found with %s: '%s'", resName,fieldName,fieldValue));
		this.resName = resName;
		this.fieldName = fieldName;
		this.fieldValue = fieldValue;
	}

	public String getResName() {
		return resName;
	}

	public String getFieldName() {
		return fieldName;
	}

	public long getFieldValue() {
		return fieldValue;
	}

}
