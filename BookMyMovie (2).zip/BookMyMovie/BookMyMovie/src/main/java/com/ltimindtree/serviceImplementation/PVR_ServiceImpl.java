package com.ltimindtree.serviceImplementation;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ltimindtree.exception.PVR_NotFound_Exception;
import com.ltimindtree.model.PVR;
import com.ltimindtree.repository.PVRRepo;
import com.ltimindtree.service.PVR_Service;

@Service
@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED, readOnly = false, timeout = 30)
public class PVR_ServiceImpl implements PVR_Service 
{
	
	@Autowired
	private PVRRepo pvrrepo;
	private final Logger log= LoggerFactory.getLogger(PVR_ServiceImpl.class);
	
	@Override
	public PVR savePVR(PVR pvr) throws JsonProcessingException {
		PVR pvr1= pvrrepo.save(pvr);
        log.info("PVR service request: {}", new ObjectMapper().writeValueAsString(pvr));
		return pvr1;
	}
	@Override
	public void saveAllPVR(List<PVR> pvr) {
		// TODO Auto-generated method stub
		pvrrepo.saveAll(pvr);
		
	}
	
	@Override
	public List<PVR> getAllPVR() {
		// TODO Auto-generated method stub
		return pvrrepo.findAll();
	}
	
	@Override
	public PVR getPVRById(long id) {
		// TODO Auto-generated method stub
		return pvrrepo.findById(id).orElseThrow(()-> new PVR_NotFound_Exception("pvr","long",id));
	}
	@Override
	public PVR updatePVR(PVR pvr, long id) throws JsonProcessingException {
		// TODO Auto-generated method stub
		pvrrepo.findById(id).orElseThrow(()-> new PVR_NotFound_Exception("pvr","long",id));
		PVR pvr1=pvrrepo.save(pvr); 
		log.info("PVR service get movie request: {}", new ObjectMapper().writeValueAsString(pvr1));
		return pvr1;
	}
	@Override
	public void deletePVRById(long id) throws JsonProcessingException {
		// TODO Auto-generated method stub
		
		PVR savedPvr = pvrrepo.findById(id).orElseThrow(()-> new PVR_NotFound_Exception("pvr","long",id));
		this.pvrrepo.delete(savedPvr);
	}
	

}
