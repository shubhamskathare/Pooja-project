package com.ltimindtree.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value=HttpStatus.NOT_FOUND)
public class InoxNotFound_Exception extends RuntimeException 
{
	private static final long serialVersionUID= 1L;
	public InoxNotFound_Exception(long id)
	{
		super();
	}

}
