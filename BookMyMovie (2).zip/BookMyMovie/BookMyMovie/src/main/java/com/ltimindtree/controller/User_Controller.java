package com.ltimindtree.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ltimindtree.model.User;
import com.ltimindtree.service.User_Service;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@EnableTransactionManagement
@ControllerAdvice
@RequestMapping("/User")
public class User_Controller {
	
	private static final Logger Logger= LoggerFactory.getLogger(User_Controller.class);
	
	@Autowired
	private User_Service userService;
	
	@PostMapping("/adduser")
	public ResponseEntity<User> saveUser(@RequestBody User user)throws JsonProcessingException
	{
		Logger.debug("User created Successfully");
		return new ResponseEntity<User>(userService.saveUser(user), HttpStatus.CREATED);
		
	}
	
	@PostMapping("/addusers")
	public void saveAllUsers(@RequestBody List<User> users)
	{
		Logger.debug("User created Successfully");
		userService.saveAllUser(users);
		
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<User> getUserById(@PathVariable long id) throws JsonProcessingException
	{
		Logger.debug("Successfully User get required by id");
		return ResponseEntity.ok(userService.getUserById(id));
		
	}
	
	@GetMapping("/allusers")
	public List<User> getAllUsers()
	{
		Logger.debug("All Users list shown Successfully");
		return userService.getAllUsers();
		
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<User> updateUser(@RequestBody User user, long id) throws JsonProcessingException
	{
		Logger.debug("successfully User Updated");
		User saveUser = userService.saveUser(user);
		if(saveUser==null)
		{
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
		}
		else
		{
			return new ResponseEntity<User>(HttpStatus.OK);
		}
		
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteUser(@PathVariable long id)throws JsonProcessingException
	{
		Logger.debug("Successfully User deleted..!");
		userService.deleteUserById(id);
		return new ResponseEntity<String>("User deleted Successfully", HttpStatus.OK);
	}

}
