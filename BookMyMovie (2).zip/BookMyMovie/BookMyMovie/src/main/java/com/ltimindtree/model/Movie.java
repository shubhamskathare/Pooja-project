package com.ltimindtree.model;

import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name= "movie")
public class Movie implements CinemaIf, Comparable<Movie> {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String title;
	private String releaseDate;
	private String showCycle;
	
	//Getter setters
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}
	public String getShowCycle() {
		return showCycle;
	}
	public void setShowCycle(String showCycle) {
		this.showCycle = showCycle;
	}
	/**
	 * @param id
	 * @param title
	 * @param releaseDate
	 * @param showCycle
	 */
	public Movie(long id, String title, String releaseDate, String showCycle) {
		super();
		this.id = id;
		this.title = title;
		this.releaseDate = releaseDate;
		this.showCycle = showCycle;
	}
	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		return Objects.hash(id, releaseDate, showCycle, title);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movie other = (Movie) obj;
		return id == other.id && Objects.equals(releaseDate, other.releaseDate)
				&& Objects.equals(showCycle, other.showCycle) && Objects.equals(title, other.title);
	}
	@Override
	public String toString() {
		return "Movie [id=" + id + ", title=" + title + ", releaseDate=" + releaseDate + ", showCycle=" + showCycle
				+ "]";
	}
	@Override
	public int compareTo(Movie o) {
		// TODO Auto-generated method stub
		return this.title.compareTo(o.title);
	}
	
	
	

}
