package com.ltimindtree.service;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ltimindtree.model.Movie;

public interface Movie_Service {
	
	public Movie saveMovie(Movie movie) throws JsonProcessingException;
	public void saveAllMovie(List<Movie> movie);
	public List<Movie> getAllMovie();
	public Movie getMovieById(long id) throws JsonProcessingException;
	public Movie updateMovie(Movie movie, long id) throws JsonProcessingException;
	public void deleteMovieById(long id) throws JsonProcessingException;
	

}
