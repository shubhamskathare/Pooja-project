package com.ltimindtree.model;

public interface CinemaIf {

}
