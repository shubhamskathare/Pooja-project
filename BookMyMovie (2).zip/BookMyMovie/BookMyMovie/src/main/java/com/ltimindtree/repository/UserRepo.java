package com.ltimindtree.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ltimindtree.model.User;

@Repository
public interface UserRepo extends JpaRepository<User, Long>  {
	
	User findById(User user);
	User getUserByName(String name);
	

}
