package com.ltimindtree.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.ltimindtree.serviceImplementation.Inox_ServiceImpl;
import com.ltimindtree.serviceImplementation.Movie_ServiceImpl;
import com.ltimindtree.serviceImplementation.PVR_ServiceImpl;
import com.ltimindtree.serviceImplementation.Screen_ServiceImpl;
import com.ltimindtree.serviceImplementation.User_ServiceImpl;

@RestControllerAdvice
public class AllExceptionHandler {
	private final Logger log1= LoggerFactory.getLogger(Inox_ServiceImpl.class);
	private final Logger log2= LoggerFactory.getLogger(Movie_ServiceImpl.class);
	private final Logger log3= LoggerFactory.getLogger(PVR_ServiceImpl.class);
	private final Logger log4= LoggerFactory.getLogger(Screen_ServiceImpl.class);
	private final Logger log5= LoggerFactory.getLogger(User_ServiceImpl.class);
	
	@ExceptionHandler(value=InoxNotFound_Exception.class)
	public ResponseEntity<Object> InoxNotFound_Exception(InoxNotFound_Exception exception)
	{
		String name="Give correct inox Id";
		log1.error("Exception in Inox.Message - {}", name);
		return new ResponseEntity<Object>("Inox ID is not found in DB",HttpStatus.NOT_FOUND);
		
	}
	
	@ExceptionHandler(value=MovieNotFound_Exception.class)
	public ResponseEntity<Object> MovieNotFound_Exception(MovieNotFound_Exception exception)
	{
		String name="Give correct Movie Id";
		log2.error("Exception in Movie.Message - {}", name);
		return new ResponseEntity<Object>("Movie ID is not found in DB",HttpStatus.NOT_FOUND);
			
	}
	
	@ExceptionHandler(value=PVR_NotFound_Exception.class)
	public ResponseEntity<Object> PVR_NotFound_Exception(PVR_NotFound_Exception exception)
	{
		String name="Give correct PVR Id";
		log3.error("Exception in PVR.Message - {}", name);
		return new ResponseEntity<Object>("PVR ID is not found in DB",HttpStatus.NOT_FOUND);
			
	}
	
	@ExceptionHandler(value=ScreenException.class)
	public ResponseEntity<Object> ScreenException(ScreenException exception)
	{
		String name="Give correct Screen Id";
		log4.error("Exception in Screen.Message - {}", name);
		return new ResponseEntity<Object>("Screen ID is not found in DB",HttpStatus.NOT_FOUND);
			
	}
	
	@ExceptionHandler(value=UserException.class)
	public ResponseEntity<Object> UserException(UserException exception)
	{
		String name="Give correct User Id";
		log5.error("Exception in User.Message - {}", name);
		return new ResponseEntity<Object>("User ID is not found in DB",HttpStatus.NOT_FOUND);
			
	}
	
	
}
