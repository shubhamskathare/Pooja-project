package com.ltimindtree.model;

import java.util.List;
import java.util.Objects;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="inox")
public class Inox implements CinemaIf, Comparable<Inox> {

	
	@Id
	private long id;
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	private List<Screen> screens;

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return the screens
	 */
	public List<Screen> getScreens() {
		return screens;
	}

	/**
	 * @param screens the screens to set
	 */
	public void setScreens(List<Screen> screens) {
		this.screens = screens;
	}


	@Override
	public int compareTo(Inox o) {
		// TODO Auto-generated method stub
		if(id>o.id) {
			return 1;
		
		} else if (Objects.equals(id, o.id)) {
			return 0;
		} else {
			return -1;
		}
	}



	/**
	 * @param id
	 * @param screens
	 */
	public Inox(long id, List<Screen> screens) {
		super();
		this.id = id;
		this.screens = screens;
	}


	/**
	 * 
	 */
	public Inox() {
		super();
		// TODO Auto-generated constructor stub
	}


	@Override
	public int hashCode() {
		return Objects.hash(id, screens);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Inox other = (Inox) obj;
		return id == other.id && Objects.equals(screens, other.screens);
	}
	
	
	
	
}
