package com.ltimindtree.serviceImplementation;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ltimindtree.exception.ScreenException;
import com.ltimindtree.model.Screen;
import com.ltimindtree.repository.ScreenRepo;
import com.ltimindtree.service.Screen_Service;

@Service
@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED, readOnly = false, timeout = 30)
public class Screen_ServiceImpl implements Screen_Service {
	
	@Autowired
	private ScreenRepo screenrepo;
	private final Logger log= LoggerFactory.getLogger(Screen_ServiceImpl.class);
	
	
	@Override
	public Screen saveScreen(Screen screen) throws JsonProcessingException {
		// TODO Auto-generated method stub
		Screen screen1= screenrepo.save(screen);
        log.info("Screen service request: {}", new ObjectMapper().writeValueAsString(screen));
		return screen1;
	}
	
	
	@Override
	public void saveAllScreen(List<Screen> screen) {
		// TODO Auto-generated method stub
		screenrepo.saveAll(screen);
		
	}
	@Override
	public List<Screen> getAllScreen() {
		// TODO Auto-generated method stub
		return screenrepo.findAll();
	}
	
	@Override
	public Screen getScreenById(long id) throws JsonProcessingException {
		// TODO Auto-generated method stub
		Screen screendb = screenrepo.findById(id).orElseThrow(()-> new ScreenException(id));
		return screendb;
				
	}
	
	@Override
	public void updateScreen(Screen screen, long id) throws JsonProcessingException {
		// TODO Auto-generated method stub
		Screen screendb = screenrepo.findById(id).orElseThrow(()-> new ScreenException(id));
		screendb.setId(screen.getId());
		screendb.setMovie(screen.getMovie());
		screendb.setType(screen.getType());
		screenrepo.save(screen);
		
		
	}
	@Override
	public void deleteScreenById(long id) throws JsonProcessingException {
		// TODO Auto-generated method stub
		
		Screen savedScreen = screenrepo.findById(id).orElseThrow(()-> new ScreenException(id));
		this.screenrepo.delete(savedScreen);
	}



	}
	
	
	
	


