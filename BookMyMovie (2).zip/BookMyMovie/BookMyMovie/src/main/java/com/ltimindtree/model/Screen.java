package com.ltimindtree.model;

import java.util.Objects;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="screen")
public class Screen implements CinemaIf, Comparable<Screen> {
	
	@Id
	private long id;
	private String type;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn
	private Movie movie;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, movie, type);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Screen other = (Screen) obj;
		return id == other.id && Objects.equals(movie, other.movie) && Objects.equals(type, other.type);
	}

	public Screen(long id, String type, Movie movie) {
		super();
		this.id = id;
		this.type = type;
		this.movie = movie;
	}

	public Screen() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public int compareTo(Screen o) {
		// TODO Auto-generated method stub
		return this.type.compareTo(o.type);
	}
	
	
	
	

}
