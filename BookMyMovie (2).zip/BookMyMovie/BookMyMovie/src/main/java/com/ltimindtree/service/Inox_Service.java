package com.ltimindtree.service;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ltimindtree.model.Inox;

public interface Inox_Service {
	
	public Inox saveInox(Inox inox) throws JsonProcessingException;
	public void saveAllInox(List<Inox> inox) throws JsonProcessingException;
	public List<Inox> getAllInox();
	public Inox getInoxById(Inox inox, long id);
	public Inox updateInox(Inox inox, long id);
	public void deleteInoxById(long id) throws JsonProcessingException;
	public Inox getInoxById(long id)throws JsonProcessingException;
	

}
