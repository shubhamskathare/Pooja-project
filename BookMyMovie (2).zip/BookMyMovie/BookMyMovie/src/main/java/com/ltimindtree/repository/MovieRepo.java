package com.ltimindtree.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ltimindtree.model.Movie;

@Repository
public interface MovieRepo extends JpaRepository<Movie, Long>{
	

}
