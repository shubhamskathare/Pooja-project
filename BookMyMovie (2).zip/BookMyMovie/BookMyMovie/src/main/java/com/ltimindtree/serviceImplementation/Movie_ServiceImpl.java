package com.ltimindtree.serviceImplementation;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ltimindtree.exception.MovieNotFound_Exception;
import com.ltimindtree.model.Movie;
import com.ltimindtree.repository.MovieRepo;
import com.ltimindtree.service.Movie_Service;

@Service
@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED, readOnly = false, timeout = 30)
public class Movie_ServiceImpl implements Movie_Service
{
	
	@Autowired
	//using @Autowired annotation we @Autowired Movie_Repository to Movie_ServiceImpl
	private MovieRepo movierepo;
	private final Logger log= LoggerFactory.getLogger(Movie_ServiceImpl.class);
	
	//This method is used to save movie using .save method
	@Override
	public Movie saveMovie(Movie movie) throws JsonProcessingException {
		Movie movie1= movierepo.save(movie);
        log.info("Movie service request: {}", new ObjectMapper().writeValueAsString(movie));
		return movie1;
	}
	
	
	@Override
	public void saveAllMovie(List<Movie> movie) {
	
		movierepo.saveAll(movie);
		
	}
	
	
	@Override
	public List<Movie> getAllMovie() {
		
		return movierepo.findAll();
	}
	
	@Override
	public Movie getMovieById(long id) throws JsonProcessingException {
		Movie moviedb = movierepo.findById(id).orElseThrow(()-> new MovieNotFound_Exception("Movie","long",id));
		return moviedb;
	}
	
	@Override
	public Movie updateMovie(Movie movie, long id) throws JsonProcessingException {
		Movie moviedb = movierepo.findById(id).orElseThrow(()-> new MovieNotFound_Exception("Movie","long",id));
		moviedb.setTitle(movie.getTitle());
		moviedb.setReleaseDate(movie.getReleaseDate());
		moviedb.setShowCycle(movie.getShowCycle());
		return movierepo.save(movie);
	}
	
	@Override
	public void deleteMovieById(long id) throws JsonProcessingException {
		Movie moviedb = movierepo.findById(id).orElseThrow(()-> new MovieNotFound_Exception("Movie","long",id));
		this.movierepo.delete(moviedb);
		
	}
	
	
	

}
