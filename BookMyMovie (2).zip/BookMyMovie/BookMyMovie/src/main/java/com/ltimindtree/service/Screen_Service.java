package com.ltimindtree.service;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ltimindtree.model.Screen;

public interface Screen_Service {
	
	public Screen saveScreen(Screen screen) throws JsonProcessingException;
	public void saveAllScreen(List<Screen> screen);
	public List<Screen> getAllScreen();
	public Screen getScreenById(long id) throws JsonProcessingException;
	public void updateScreen(Screen screen, long id) throws JsonProcessingException;
	public void deleteScreenById(long id) throws JsonProcessingException;

}
