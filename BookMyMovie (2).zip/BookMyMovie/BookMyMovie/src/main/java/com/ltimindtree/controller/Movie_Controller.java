package com.ltimindtree.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ltimindtree.model.Movie;
import com.ltimindtree.service.Movie_Service;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@EnableTransactionManagement
@ControllerAdvice
@RequestMapping("/movie")
public class Movie_Controller {
	
	private static final Logger Logger= LoggerFactory.getLogger(Movie_Controller.class);
	
	@Autowired
	private Movie_Service movieService;
	
	@PostMapping("/addmovie")
	public ResponseEntity<Movie> saveMovie (@RequestBody Movie movie) throws JsonProcessingException
	{
		System.out.println(movie);
		Logger.debug("Movie Created Successfully..");
		return new ResponseEntity<Movie>(movieService.saveMovie(movie),HttpStatus.CREATED);
	}
	
	@PostMapping("/addmovies")
	public void saveAllMovies(@RequestBody List<Movie> movies)
	{
		Logger.debug("Movie Created Successfully..");
		movieService.saveAllMovie(movies);
		
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Movie> getMovieById(@PathVariable(name="id") long id) throws JsonProcessingException
	{
		Logger.debug("Successfully get required by id");
		return ResponseEntity.ok(movieService.getMovieById(id));
		
	}
	
	@GetMapping("/allmovies")
	public List<Movie> getAllMovies()
	{
		Logger.debug("All movie list shown Successfully");
		return movieService.getAllMovie();
		
	}
	
	@PutMapping("/updatemovies")
	public ResponseEntity<Movie> updateMovies(@RequestBody Movie movie, @PathVariable(name="id") long id) throws JsonProcessingException
	{
		Logger.debug("successfully movie Updated");
		Movie movieResponse = movieService.updateMovie(movie, id);
		return new ResponseEntity<>(movieResponse,HttpStatus.OK);
		
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteMovie(@PathVariable long id)throws JsonProcessingException
	{
		Logger.debug("Successfully movie deleted..!");
		movieService.deleteMovieById(id);
		return new ResponseEntity<>("movie deleted Successfully", HttpStatus.OK);
	}
	
	

}
