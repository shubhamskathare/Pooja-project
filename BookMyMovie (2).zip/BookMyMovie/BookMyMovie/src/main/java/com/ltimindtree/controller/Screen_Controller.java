package com.ltimindtree.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ltimindtree.model.Screen;
import com.ltimindtree.service.Screen_Service;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@EnableTransactionManagement
@ControllerAdvice
@RequestMapping("/Screen")
public class Screen_Controller {
	
	private static final Logger Logger= LoggerFactory.getLogger(Screen_Controller.class);
	
	@Autowired
	private Screen_Service ScreenService;
	
	@PostMapping("/addscreen")
	public ResponseEntity<Screen> saveScreen(@RequestBody Screen screen)throws Exception
	{
		Logger.debug("Screen created Successfully");
		return new ResponseEntity<Screen>(ScreenService.saveScreen(screen), HttpStatus.CREATED);
		
	}
	
	@PostMapping("/addscreens")
	public void saveAllScreen(@RequestBody List<Screen> screens)
	{
		Logger.debug("Screen created Successfully");
		ScreenService.saveAllScreen(screens);
		
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Screen> getScreen(@PathVariable long id) throws JsonProcessingException
	{
		Logger.debug("Successfully get Screen required by id");
		return ResponseEntity.ok(ScreenService.getScreenById(id));
		
	}
	
	@GetMapping("/alLscreens")
	public List<Screen> getAllScreens()
	{
		Logger.debug("All Screen list shown Successfully");
		return ScreenService.getAllScreen();
		
	}
	
	@PutMapping("/updatescreen")
	public ResponseEntity<Screen> updateScreen(@RequestBody Screen screen, long id) throws JsonProcessingException
	{
		Logger.debug("successfully Screen Updated");
		Screen saveScreen = ScreenService.saveScreen(screen);
		if(saveScreen== null)
		{
		return new ResponseEntity<Screen>(HttpStatus.NOT_FOUND);
		
		}
		else
		{
			return new ResponseEntity<Screen>(HttpStatus.OK);
		}
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteScreen(@PathVariable long id)throws JsonProcessingException
	{
		Logger.debug("Successfully Screen deleted..!");
		ScreenService.deleteScreenById(id);
		return new ResponseEntity<>("Screen deleted Successfully", HttpStatus.OK);
	}

}
