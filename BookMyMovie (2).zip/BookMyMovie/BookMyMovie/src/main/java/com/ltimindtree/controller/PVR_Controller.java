package com.ltimindtree.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ltimindtree.model.PVR;
import com.ltimindtree.service.PVR_Service;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@EnableTransactionManagement
@ControllerAdvice
@RequestMapping("/pvr")
public class PVR_Controller {
	
	private static final Logger Logger= LoggerFactory.getLogger(PVR_Controller.class);
	
	@Autowired
	private PVR_Service pvrService;
	
	@PostMapping("/addpvr")
	public ResponseEntity<PVR> savePVR(@RequestBody PVR pvr)throws Exception
	{
		Logger.debug("PVR created Successfully");
		return new ResponseEntity<PVR>(pvrService.savePVR(pvr), HttpStatus.CREATED);
		
	}
	
	@PostMapping("/addpvrs")
	public void saveAllPVR(@RequestBody List<PVR> pvrs)
	{
		Logger.debug("PVR created Successfully");
		pvrService.saveAllPVR(pvrs);
		
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<PVR> getPVRById(@PathVariable(name="id") long id) throws JsonProcessingException
	{
		Logger.debug("Successfully PVR get required by id");
		return ResponseEntity.ok(pvrService.getPVRById(id));
		
	}
	
	@GetMapping("/alLpvr")
	public List<PVR> getAllPVR()
	{
		Logger.debug("All PVR list shown Successfully");
		return pvrService.getAllPVR();
		
	}
	
	@PutMapping("/updatepvr")
	public ResponseEntity<PVR> updatePvr(@RequestBody PVR pvr, @PathVariable(name="id") long id) throws JsonProcessingException
	{
		Logger.debug("successfully pvr Updated");
		PVR pvrResponse = pvrService.updatePVR(pvr, id);
		return new ResponseEntity<>(pvrResponse,HttpStatus.OK);
		
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deletePvr(@PathVariable long id)throws JsonProcessingException
	{
		Logger.debug("Successfully pvr deleted..!");
		pvrService.deletePVRById(id);
		return new ResponseEntity<>("Pvr deleted Successfully", HttpStatus.OK);
	}
	

}
