package com.ltimindtree.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ltimindtree.exception.InoxNotFound_Exception;
import com.ltimindtree.model.Inox;
import com.ltimindtree.service.Inox_Service;

import lombok.extern.slf4j.Slf4j;


@RestController
@EnableTransactionManagement
@ControllerAdvice
@Slf4j
@RequestMapping("/inox")
public class Inox_Controller {
	
	private static final Logger Logger= LoggerFactory.getLogger(Inox_Controller.class);
	
	@Autowired
	private Inox_Service inoxService;
	
	@PostMapping("/addinox")
	public ResponseEntity<Inox> saveInox (@RequestBody Inox inox) throws Exception
	{
		Logger.debug("Inox created successfully");
		return ResponseEntity.status(HttpStatus.CREATED).body(inoxService.saveInox(inox));
	}
	
	@PostMapping("/addinoxes")
	public void saveAllInox(@RequestBody List<Inox> inoxs) throws JsonProcessingException
	{
		Logger.debug("Inox created successfully");
		inoxService.saveAllInox(inoxs);
		
		
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Inox> getInoxById(@PathVariable long id) throws InoxNotFound_Exception, JsonProcessingException
	{
		Logger.debug("We get required Inox successfully");
		Inox savedinox = inoxService.getInoxById(id);
		if(savedinox == null)
		{
			return new ResponseEntity<Inox>(HttpStatus.NOT_FOUND);
		}
		else
		{
			return new ResponseEntity<Inox>(savedinox, HttpStatus.OK);
		}
	}
	
	@GetMapping("/allinoxes")
	public List<Inox> getAllInoxes()
	{
		Logger.debug("Successfully we get all inoxes");
		return inoxService.getAllInox();
	}
	
	@PutMapping("/updateinoxes")
	public ResponseEntity<?> updateInox(@RequestBody Inox inox, long id)throws JsonProcessingException
	{
		Logger.debug("Inox Updated successfully");
		
		if(inox == null)
			return ResponseEntity.badRequest().body("The provided iox is not valid");
		return ResponseEntity.status(HttpStatus.CREATED).body(inoxService.saveInox(inox));
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteInox(@PathVariable long id)throws JsonProcessingException
	{
		Logger.debug("Inox Deleted Successfully");
		inoxService.deleteInoxById(id);
		return new ResponseEntity<String>("Inox deleted Successfully", HttpStatus.OK);
		
		
	}


}
