package com.ltimindtree.service;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ltimindtree.model.PVR;

public interface PVR_Service {
	
	public PVR savePVR(PVR pvr) throws JsonProcessingException;
	public void saveAllPVR(List<PVR> pvr);
	public List<PVR> getAllPVR();
	public PVR getPVRById(long id);
	public PVR updatePVR(PVR pvr, long id) throws JsonProcessingException;
	public void deletePVRById(long id) throws JsonProcessingException;

}
