package com.ltimindtree.serviceImplementation;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ltimindtree.exception.InoxNotFound_Exception;
import com.ltimindtree.model.Inox;
import com.ltimindtree.repository.InoxRepo;
import com.ltimindtree.service.Inox_Service;



@Service
@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED, readOnly = false, timeout = 30)
public class Inox_ServiceImpl implements Inox_Service
{
	
	@Autowired
	private InoxRepo inoxrepo;
	
	private final Logger log= LoggerFactory.getLogger(Inox_ServiceImpl.class);

	@Override
	//This method is to saveInox using .save method
	public Inox saveInox(Inox inox) throws JsonProcessingException {
		log.info("Inox service request: {}", new ObjectMapper().writeValueAsString(inox));
		
		Inox inox1= inoxrepo.save(inox);
		return inox1;
	}

	@Override
	//this method is to saveAllInox  list using .saveAll method
	public void saveAllInox(List<Inox> inox) throws JsonProcessingException {
	log.info("Inox service getmovie request: {}", new ObjectMapper().writeValueAsString(inox));
		inoxrepo.saveAll(inox);
		
	}

	@Override
	//this method is used to getAllInox using .findById method
	public List<Inox> getAllInox() {
		
		return inoxrepo.findAll();
	}

	@Override
	//This method is to getinoxById using .findById method
	public Inox getInoxById(Inox inox, long id) {
		// TODO Auto-generated method stub
	
		return inoxrepo.findById(id).orElseThrow(()-> new InoxNotFound_Exception(id));
	}

	@Override
	//this method is updateInox list using .save method
	public Inox updateInox(Inox inox, long id) {
		// TODO Auto-generated method stub
		return inoxrepo.findById(id).orElseThrow(()-> new InoxNotFound_Exception(id));
	}

	@Override
	//this method is use to deleteInoxById using .deleteById method
	public void deleteInoxById(long id) throws JsonProcessingException {
		// TODO Auto-generated method stub
		inoxrepo.deleteById(id);
	}

	@Override
	public Inox getInoxById(long id) throws JsonProcessingException {
		// TODO Auto-generated method stub
		return inoxrepo.findById(id).orElseThrow(()-> new InoxNotFound_Exception(id));
	}
	
	
	

}
