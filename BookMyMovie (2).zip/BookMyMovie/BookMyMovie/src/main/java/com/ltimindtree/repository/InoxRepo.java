package com.ltimindtree.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ltimindtree.model.Inox;

@Repository
public interface InoxRepo extends JpaRepository<Inox, Long> {
	
	Inox getById(long id);

}
