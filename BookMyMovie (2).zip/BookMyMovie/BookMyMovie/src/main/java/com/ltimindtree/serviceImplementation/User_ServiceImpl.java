package com.ltimindtree.serviceImplementation;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ltimindtree.exception.UserException;
import com.ltimindtree.model.User;
import com.ltimindtree.repository.UserRepo;
import com.ltimindtree.service.User_Service;

@Service
@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED, readOnly = false, timeout = 30)
public class User_ServiceImpl implements User_Service {
	
	@Autowired
	private UserRepo userrepo;
	private final Logger log= LoggerFactory.getLogger(User_ServiceImpl.class);
	
	@Override
	public User saveUser(User user) throws JsonProcessingException {
		// TODO Auto-generated method stub
		User user1 = userrepo.save(user);
		log.info("user service request : {}", new ObjectMapper().writeValueAsString(user1));
		return user1;
	}
	@Override
	public void saveAllUser(List<User> getAllUser) {
		// TODO Auto-generated method stub
		userrepo.saveAll(getAllUser);
		
	}
	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userrepo.findAll();
	}
	@Override
	public User getUserById(long id) throws JsonProcessingException {
		// TODO Auto-generated method stub
		User userdb=userrepo.findById(id).orElseThrow(()-> new UserException("user","long", id));
		return userdb;
	}
	@Override
	public void updateUser(User user, long id) throws JsonProcessingException {
		// TODO Auto-generated method stub
		log.info("User service request : {}", new ObjectMapper().writeValueAsString(user));
		User userdb = userrepo.findById(id).orElseThrow(()-> new UserException("user","long", id));
		userdb.setName(user.getName());
		userdb.setInox(user.getInox());
		userdb.setPassword(user.getPassword());
		userdb.setPvr(user.getPvr());
	}
	@Override
	public void deleteUserById(long id) throws JsonProcessingException {
		// TODO Auto-generated method stub
		User savedUser = userrepo.findById(id).orElseThrow(()-> new UserException("user","long", id));
		this.userrepo.delete(savedUser);
		
	}
	@Override
	public User getUserByName(String name) {
		// TODO Auto-generated method stub
		return userrepo.getUserByName(name);
	}

}
